/*:
## Solução do FizzBuzz com Condicionais
 
 A solução mais utilizada para o desafio é utilizando condicionais e, naturalmente, um loop:
 
 */
// Codifique aqui sua solução


/*:
[Anterior](@previous)  |  página 2 de 7  |  [Próximo: Solução com Switch](@next)
 */
