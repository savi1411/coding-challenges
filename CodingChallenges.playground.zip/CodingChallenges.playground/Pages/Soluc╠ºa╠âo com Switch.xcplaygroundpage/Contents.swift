/*:
## Solução do FizzBuzz com Switch Case
 
 Uma boa alternativa para solucionar o enigma é utilizando switch e, naturalmente, um loop também:
 
 */
// Codifique aqui sua solução

/*:
[Anterior](@previous)  |  página 3 of 7  |  [Próximo: Palíndromo](@next)
 */
